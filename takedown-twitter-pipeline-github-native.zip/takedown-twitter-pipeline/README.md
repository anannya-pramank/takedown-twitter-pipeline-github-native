# takedown-twitter-pipeline (GitHub-native)

Monitors Twitter for Indian government/court content-takedown activity
(Section 69A, IT Rules 2021, MeitY blocking orders, etc.), gates each tweet
for relevance in two tiers (free embedding similarity, then a cheap Gemini
call only for the ambiguous band), and writes the survivors to Supabase with
an embedding column for later semantic search.

This is a straight re-architecture of the original AWS version — same
`fetch_tweets.py` retry logic, same `keywords.yaml`, same two-tier gate, same
`takedown_tweets` schema — with the AWS scaffolding removed:

| Was | Now |
|---|---|
| ECS Fargate + EventBridge Scheduler | one step in `.github/workflows/twitter-pipeline.yml`, `schedule: cron` |
| SQS + DLQ + Lambda | next step, same job — per-item try/except instead of a queue |
| S3 raw landing | `raw-data` branch, committed each run |
| Secrets Manager | repo Actions secrets |
| RDS Postgres + pgvector | Supabase (same schema, same conventions as CERC) |
| ECR + Docker image builds | gone — the runner installs deps and runs Python directly |
| 4 IAM roles | gone |
| SNS + CloudWatch alarm | job failure -> GitHub email + auto-filed/closed issue |

See `infra/setup-guide.md` for the five-step setup. `infra/schema.sql` is
what to run once against Supabase before the first scheduled run.

## Layout

```
.github/workflows/twitter-pipeline.yml   the whole pipeline — schedule, fetch, gate, alerting
fetch/fetch_tweets.py                    calls twitter-cli, writes raw/<run_id>.json
process/gate_tweets.py                   tier-1/tier-2 relevance gate, writes to Supabase
config/keywords.yaml                     queries + handles (unchanged from the AWS version)
infra/schema.sql                         takedown_tweets table + HNSW index + coverage view
infra/setup-guide.md                     one-time setup
```
